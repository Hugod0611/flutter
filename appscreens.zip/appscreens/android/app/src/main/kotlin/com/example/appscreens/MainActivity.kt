package com.example.appscreens

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
