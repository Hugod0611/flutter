
import 'package:flutter/material.dart';
import 'package:appscreens/src/screens/welcome_screen.dart';

void main() => runApp(const SplashScreen());

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Material App',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Pantalla de Inicio'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Hola', 
              style: TextStyle(
                fontSize: 72,
                fontWeight: FontWeight.w200,
                color: Colors.red
              ),
              ),
              const SizedBox(
                height: 20,
              ),
              TextButton(
                onPressed: () => Navigator.push(
                    context,
                  MaterialPageRoute(builder: (context) => const WelcomeScreen()),
                  ),
                style: TextButton.styleFrom(
                  side: const BorderSide(color:Colors.black, width: 2)
                ),
                child: const Text("Bienvenido"),
                ), 
            ],
          ),
        ),
      ),
    );
  }
}