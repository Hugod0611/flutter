import 'package:appscreens/src/screens/start_screen.dart';
import 'package:flutter/material.dart';

void main() => runApp(const WelcomeScreen());

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Material App',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Pantalla de Bienvenida'),
        ),
        body:  Center(
          child: Column(
            children: [
              SizedBox(
                height: 200,
                width: double.infinity,
                child:  Image.asset('assets/images/foto_welcome.jpg', fit: BoxFit.cover) 
              ),
              const Text('Loki',
              style: TextStyle(fontSize: 72,
              fontWeight: FontWeight.bold,
              color:Colors.red),
              ),

              const Padding(
                padding: EdgeInsets.all(25),
                child: Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum",
                textAlign: TextAlign.center,)
              ),
              
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: ()=> Navigator.push(
                      context, MaterialPageRoute(builder: (context) => const StartScreen()
                      )
                    ), 
                    child: const Text("Empezar"))
                  
                  ),
                
                )
            ],
          ),
        ),
      ),
    );
  }
}