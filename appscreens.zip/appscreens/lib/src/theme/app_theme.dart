import 'package:appscreens/src/screens/utils/app_colors.dart';
import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
        //colores para fondos
        colorScheme: const ColorScheme.light(
          primary: AppColors.primary,
          primaryContainer: AppColors.primaryVariant,
          secondary: AppColors.secondary,
          error: AppColors.error,
          surface: AppColors.surface,

          //Colores para textos
          onPrimary: AppColors.onPrimary,
          onSecondary: AppColors.onSecondary,
          onSurface: AppColors.onSurface,
          onError: AppColors.onError,
        ),
        textTheme: const TextTheme(
            displayLarge: TextStyle(fontSize: 84, fontWeight: FontWeight.w200),
            headlineLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.w900),
            bodyMedium: TextStyle(fontSize: 16)),
        buttonTheme: const ButtonThemeData(
            buttonColor: AppColors.secondary,
            textTheme: ButtonTextTheme.primary),
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.onPrimary,
        )));
  }
}
