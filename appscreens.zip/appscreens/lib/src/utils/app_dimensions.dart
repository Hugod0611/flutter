class AppDimensions {
static const double tinyPadding=5.0;
static const double smallPadding=10.0;
static const double mediumPadding=20.0;
static const double largePadding=40.0;
static const double xlargePadding=80.0;


}